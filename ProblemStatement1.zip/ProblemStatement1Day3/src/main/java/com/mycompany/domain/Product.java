package com.mycompany.domain;
/*POJO - plain old java object - classes which are supposed to hold data */
public class Product {

    //since this class holds the same data as the db table, it should have the same fields as the table
    String Product_Id;
    String Product_Name;
    int Product_Price;

    //default constructor
    public Product(){

    }

    public Product(String Product_Id, String Product_Name, int Product_Price) {
        this.Product_Id =  Product_Id;
        this.Product_Name = Product_Name;
        this.Product_Price = Product_Price;
    }

	public String getProduct_Id() {
		return Product_Id;
	}

	public void setProduct_Id(String product_Id) {
		Product_Id = product_Id;
	}

	public String getProduct_Name() {
		return Product_Name;
	}

	public void setProduct_Name(String product_Name) {
		Product_Name = product_Name;
	}

	public int getProduct_Price() {
		return Product_Price;
	}

	public void setProduct_Price(int product_Price) {
		Product_Price = product_Price;
	}

	@Override
	public String toString() {
		return "Product [Product_Id=" + Product_Id + ", Product_Name=" + Product_Name + ", Product_Price="
				+ Product_Price + "]";
	}

   
}
