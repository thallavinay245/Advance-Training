package com;

import java.util.LinkedList;

public class Main {
	public static void main(String[] args) 
	{
		LinkedList<Employee> v=addInput();
		display(v);
	}
	public static LinkedList<Employee> addInput()
	{
		Employee e1=new Employee(501,"Jayanth","Rajahmundry");
		Employee e2=new Employee(502,"Vinay","Hyderabad");
		Employee e3=new Employee(503,"Baji","Guntur");
		Employee e4=new Employee(504,"Lokesh","Vijayawada");
		
		LinkedList<Employee>l = new LinkedList<Employee>();
		l.add(e1);
		l.add(e2);
		l.add(e3);
		l.add(e4);
		return l;
	}
	public static void display(LinkedList<Employee>v)
	{
		for(Employee e:v)
		{
			System.out.println(e.getEmpid()+"\t"+e.getEmpName()+"\t"+e.getAddress());
		}

	}
}
